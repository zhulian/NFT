import { useState } from "react";
import "./App.css";
import MainMint from "./MainMint";
import NavBar from "./NavBar";
function App() {
  const [accounts, setAccounts] = useState([]);
  return (
    <div className="App">
      <h1> Simple NFT Mint Demo </h1>
      <NavBar accounts={accounts} setAccounts={setAccounts} />
      <MainMint accounts={accounts} setAccounts={setAccounts} />
    </div>
  );
}

export default App;
