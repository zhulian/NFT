import { boolean } from "hardhat/internal/core/params/argumentTypes";
import React from "react";
import { Box, Button, Flex, Image, Link, Spacer } from "@chakra-ui/react";

const NavBar = ({ accounts, setAccounts }) => {
  const isConnected = Boolean(accounts[0]);
  async function connectAccount() {
    if (window.ethereum) {
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      });
      setAccounts(accounts);
    }
  }
  return (
    <Flex justify={"space-between"} align="center" padding="30px">
      <div>About</div>
      <div>Mint</div>
      <div>Developer</div>

      {isConnected ? (
        <Box margin="0 15px">Connected</Box>
      ) : (
        <Button boxShadow="0px 2px 2px 1px #0F0F0F" onClick={connectAccount}>
          Connect
        </Button>
      )}
    </Flex>
  );
};
export default NavBar;
