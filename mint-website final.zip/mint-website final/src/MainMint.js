import { useState, useEffect } from "react";
import { ethers, BigNumber } from "ethers";
import SimpleNFT from "./SimpleNFT.json";
import {
  Box,
  Button,
  Flex,
  Image,
  Link,
  Spacer,
  Input,
  Grid,
  HStack,
  Center,
  Text,
  Stack,
} from "@chakra-ui/react";
import { extendTheme, ChakraProvider } from "@chakra-ui/react";

const SimpleNFTAddress = "0x32911006c849a923F99e1bE627BBA48eb0C15799"; //"0xF7a686db9d273Cfa2EbC4339301581c25a7C13d0"; //"0x0946e1a321C7e82Aed45538E852bCE4D37E935D5"; //"0x621033F5F5F7b076BcB47D509d0828Ba6eC407Ed"; //"0x37A88759316900d46A20Fdb69dB96cd24F24318c";
//const wallet = "0x9ec5Dfd5dEe126D06D9dC5E2E8eFe21D4C525812";
const MainMint = ({ accounts, setAccounts }) => {
  const [mintAmount, setMintAmount] = useState(1);
  const isConnected = Boolean(accounts[0]);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const colors = {
    brand: {
      900: "#1a365d",
      800: "#153e75",
      700: "#2a69ac",
    },
  };

  const theme = extendTheme({ colors });
  useEffect(() => {
    console.log("data is going to change....");
    async function getMetadata() {
      if (window.ethereum) {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const Contract = new ethers.Contract(
          SimpleNFTAddress,
          SimpleNFT.abi,
          signer
        );
        try {
          const metadata = await Contract.getMetadata();

          console.log("meatadata: ", metadata.name);
          // Update the state variables with the metadata properties
          setName(metadata.name);
          setDescription(metadata.description);
          setImage(metadata.image);
        } catch (err) {
          console.log("error: ", err);
        }
      }
    }

    // Call the getMetadata function when the component mounts
    getMetadata();
  }, []);

  async function handleMint() {
    if (window.ethereum) {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const Contract = new ethers.Contract(
        SimpleNFTAddress,
        SimpleNFT.abi,
        signer
      );
      try {
        const sp = await Contract.setIsPublicMintEnable(true);
        await sp.wait();
        const response = await Contract.mint(BigNumber.from(mintAmount), {
          gasLimit: 5000000,
        });
        console.log("response: ", response);

        //verification for minted successfully
        const receipt = await response.wait();
        console.log("transaction is done.");
        const tokenId = receipt.events[0].args.tokenId.toNumber();
        console.log("tokenid: ", tokenId);
        console.log("Minted successfully!");
      } catch (err) {
        console.log("error: ", err);
      }
    }
  }

  const handleDecrement = () => {
    if (mintAmount >= 5) return;
    setMintAmount(mintAmount - 1);
  };
  const handleIncrement = () => {
    if (mintAmount <= 0) return;
    setMintAmount(mintAmount + 1);
  };

  async function setMetadata() {
    if (window.ethereum) {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const Contract = new ethers.Contract(
        SimpleNFTAddress,
        SimpleNFT.abi,
        signer
      );
      try {
        const sm = await Contract.setMetadata(
          "My Simple NFT",
          "This a simple NFT.",
          "https://gateway.pinata.cloud/ipfs/QmPqashWjHxjPk8XLM3HMND1xsdcQvSDP62ovEoZhZnh9Y"
        );
        await sm.wait();
        // console.log("meatadata: ", metadata);
      } catch (err) {
        console.log("error: ", err);
      }
    }
  }

  return (
    <ChakraProvider theme={theme}>
      {isConnected ? (
        <Stack spacing={3}>
          <Center>
            <Button colorScheme="blue" w="300px" h="50px" onClick={setMetadata}>
              Set Metadata
            </Button>
          </Center>
          <Center>
            <Box>
              <Text fontSize="6xl">{name}</Text>
              <Text fontSize="xl">{description}</Text>
              <Image src={image} />
            </Box>
          </Center>
          <Center>
            <HStack>
              <Center w="40px" h="40px" bg="teal" color="white">
                <Box
                  as="span"
                  fontWeight="bold"
                  fontSize="lg"
                  onClick={handleDecrement}
                >
                  -
                </Box>
              </Center>
              <Center w="40px" h="40px" bg="white" color="black">
                <Input
                  placeholder="Basic usage"
                  size="sm"
                  type="number"
                  value={mintAmount}
                ></Input>
              </Center>
              <Center w="40px" h="40px" bg="teal" color="white">
                <Box
                  as="span"
                  fontWeight="bold"
                  fontSize="lg"
                  onClick={handleIncrement}
                >
                  +
                </Box>
              </Center>
            </HStack>
          </Center>
          <Center>
            <Button colorScheme="teal" w="200px" h="50px" onClick={handleMint}>
              Mint Now
            </Button>
          </Center>
        </Stack>
      ) : (
        <p>You must connected to mint.</p>
      )}
    </ChakraProvider>
  );
};
export default MainMint;
