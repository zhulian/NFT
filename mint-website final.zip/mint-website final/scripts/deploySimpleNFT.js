const hre = require("hardhat");

async function main() {
  const SimpleNFT = await hre.ethers.getContractFactory("SimpleNFT");

  const gasPrice = await SimpleNFT.signer.getGasPrice();
  console.log(`Current gas price: ${gasPrice}`);

  const estimatedGas = await SimpleNFT.signer.estimateGas(
    SimpleNFT.getDeployTransaction()
  );
  console.log(`Estimated gas: ${estimatedGas}`);

  const deploymentPrice = gasPrice.mul(estimatedGas);
  const deployerBalance = await SimpleNFT.signer.getBalance();
  console.log(
    `Deployer balance:  ${ethers.utils.formatEther(deployerBalance)}`
  );
  console.log(
    `Deployment price:  ${ethers.utils.formatEther(deploymentPrice)}`
  );
  if (deployerBalance.lt(deploymentPrice)) {
    throw new Error(
      `Insufficient funds. Top up your account balance by ${ethers.utils.formatEther(
        deploymentPrice.sub(deployerBalance)
      )}`
    );
  }

  const simpleNFT = await SimpleNFT.deploy({ gasPrice: 90000000000 });
  await simpleNFT.deployed();

  console.log("SimpleNFT deployed to:" + simpleNFT.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
