require("@nomicfoundation/hardhat-toolbox");
require("@nomiclabs/hardhat-etherscan");

const dotenv = require("dotenv");
dotenv.config();
task("accounts", "Prints list of accounts", async (taskArgs, hre) => {
  const accounts = await hre.ethers.getSigners();
  for (const account of accounts) {
    console.log(account.addresse);
  }
});
/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.17",
  networks: {
    goerli: {
      url: process.env.REACT_APP_GOERLI_RPC_URL,
      accounts: [process.env.REACT_APP_WALLET_PRIVATE_KEY],
    },
  },
  archemy: {
    apikey: process.env.REACT_APP_ARCHEMY_API_KEY,
  },
  etherscan: {
    apiKey: "F3HDU2M6822KRG2MWG8V2UC4QUF7CJBUQX",
  },
};
